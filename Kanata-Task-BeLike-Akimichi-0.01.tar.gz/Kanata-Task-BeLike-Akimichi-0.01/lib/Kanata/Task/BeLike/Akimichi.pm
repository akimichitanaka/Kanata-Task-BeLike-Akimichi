package Kanata::Task::BeLike::Akimichi;
use strict;
use warnings;
our $VERSION = '0.01';

1;
__END__

=head1 NAME

Kanata::Task::BeLike::Akimichi -

=head1 SYNOPSIS

  use Kanata::Task::BeLike::Akimichi;

=head1 DESCRIPTION

Kanata::Task::BeLike::Akimichi is based on Task::BeLike::Tokuhirom

=head1 AUTHOR

akimichi E<lt>akimichi@thekanata.jpE<gt>

=head1 SEE ALSO

=head1 LICENSE

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=cut
